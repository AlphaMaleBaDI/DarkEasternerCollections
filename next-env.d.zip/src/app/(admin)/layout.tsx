import React from 'react';
import { createClient } from '@/lib/supabase/client';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = createClient();
  const { data: { session } } = await supabase.auth.getSession();

  if (!session) {
    redirect('/login');
  }

  const menuItems = [
    { name: 'Dashboard', href: '/admin' },
    { name: 'Products', href: '/admin/products' },
    { name: 'Media', href: '/admin/media' },
    { name: 'Collections', href: '/admin/collections' },
    { name: 'Inquiries', href: '/admin/inquiries' },
    { name: 'Orders', href: '/admin/orders' },
    { name: 'Site Content', href: '/admin/site-content' },
  ];

  return (
    <div className="flex min-h-screen bg-zinc-950 text-soft-white">
      {/* Sidebar */}
      <aside className="w-64 border-r border-white/10 flex flex-col bg-zinc-900/50 backdrop-blur-xl">
        <div className="p-6 border-b border-white/10">
          <h1 className="font-heading text-xl tracking-tighter text-luxury-gold">
            Cynthia Admin
          </h1>
          <p className="text-[10px] uppercase tracking-widest text-white/40 mt-1">
            House Management
          </p>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => (
            <Link 
              key={item.href} 
              href={item.href}
              className="block px-4 py-3 text-xs uppercase tracking-widest text-white/60 hover:text-luxury-gold hover:bg-white/5 transition-all duration-300 rounded-md"
            >
              {item.name}
            </Link>
          ))}
        </nav>
        
        <div className="p-4 border-t border-white/10">
          <button 
            onClick={async () => {
              await supabase.auth.signOut();
              window.location.href = '/';
            }}
            className="w-full px-4 py-2 text-[10px] uppercase tracking-widest text-white/40 hover:text-white transition-colors text-center"
          >
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 border-b border-white/10 flex items-center justify-between px-8 bg-zinc-950/50 backdrop-blur-md">
          <div className="text-xs uppercase tracking-widest text-white/40">
            Admin Suite / <span className="text-white">Management</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-2 h-2 rounded-full bg-luxury-gold animate-pulse" />
            <span className="text-[10px] uppercase tracking-widest text-white/60">Secure Session</span>
          </div>
        </header>
        
        <div className="flex-1 overflow-y-auto p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
